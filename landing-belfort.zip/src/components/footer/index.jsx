function Footer() {
    return (
        <footer className="bg-gray-900 text-center py-4 text-xs">
            <div className="text-white">Todos os direitos reservados © 2025 Belfort Engenharia</div>
        </footer>
    )
}

export default Footer